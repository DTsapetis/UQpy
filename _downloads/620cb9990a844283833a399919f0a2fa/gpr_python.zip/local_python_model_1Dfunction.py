"""

Auxiliary file
==============================================

"""
def y_func(z):
    import numpy as np
    return np.sin(z)

